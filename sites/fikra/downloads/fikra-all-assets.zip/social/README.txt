ZABIBU FIKRA — SOCIAL & DIGITAL MERCH

Avatars (1024 × 1024):
- avatar-red.png / avatar-paper.png

Banners:
- x-header.png            1500 × 500
- linkedin.png            1584 × 396
- youtube.png             2560 × 1440

Posts and stories:
- square.png              1080 × 1080
- story.png               1080 × 1920
- stickers.png            1200 × 1200
- poster.png              2480 × 3508 (A3 ratio)

Badges:
- built-with-fikra.svg
- powered-by-fikra.svg

Usage: see usage.txt. Do not alter the mark or imply endorsement.
