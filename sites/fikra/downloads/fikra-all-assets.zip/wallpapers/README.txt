ZABIBU FIKRA — WALLPAPERS

Desktop 1920 × 1080:
- wallpaper-red-desktop.png
- wallpaper-paper-desktop.png
- wallpaper-ink-desktop.png
- wallpaper-pale-desktop.png

Mobile 1170 × 2532:
- wallpaper-red-mobile.png
- wallpaper-paper-mobile.png
- wallpaper-ink-mobile.png
- wallpaper-pale-mobile.png

Free for personal use. Do not alter the mark or imply endorsement.
