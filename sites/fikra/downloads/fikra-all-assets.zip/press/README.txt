ZABIBU FIKRA — PRESS KIT

Contents:
- fikra-press-kit.pdf          two-page press kit
- fikra-model-fact-sheet.pdf   one-page fact sheet
- brand-light.png / brand-dark.png
- og-fikra.png
- model2-card.png / model1-card.png
- boilerplate.txt / key-facts.txt

All facts are from the public model card and benchmarks.
Contact: https://zabibu.vercel.app/contact
