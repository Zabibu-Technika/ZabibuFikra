ZABIBU FIKRA — BRAND KIT

Contents:
- brand-dark.png       logo for ink / dark backgrounds
- brand-light.png      logo for paper / light backgrounds
- brand-on-red.png     logo for Fikra Red backgrounds
- fikra-heart.svg      red wireframe heart
- fikra-heart-paper.svg  paper wireframe heart
- favicon.ico / favicon.svg / favicon-32.png / favicon-48.png
- apple-touch-icon.png / icon-192.png / icon-512.png
- og-fikra.png / og-assets.png
- palette.txt / typography.txt / usage.txt

Usage: see usage.txt. Do not alter the mark or imply endorsement.
Contact: https://zabibu.vercel.app/contact
