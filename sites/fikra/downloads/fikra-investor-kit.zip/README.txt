ZABIBU FIKRA — INVESTOR KIT

Contents:
- fikra-investor-one-pager.pdf  company and product overview
- fikra-model-fact-sheet.pdf    model fact sheet
- brand-light.png / brand-dark.png
- investor-overview.txt

The overview is for information only and is not an offer to sell
securities. Financial detail, cap table, and diligence materials are
available under NDA on request.
Contact: https://zabibu.vercel.app/contact
